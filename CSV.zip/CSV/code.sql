-- Table remdoc
CREATE TABLE remdoc (
    MODU VARCHAR(255),
    NDOS VARCHAR(255),
    ETA VARCHAR(255),
    DEV INT,
    NOMT VARCHAR(255),
    MDEV NUMERIC,
	TDEV NUMERIC,
	MT_LOC NUMERIC,
	DVA DATE,
    OPEO NUMERIC,
    DOU DATE,
    CLI INT,
    NOM VARCHAR(255),
    GES VARCHAR(255),
    NOMGES VARCHAR(255)
);

-- Table rapatriement
CREATE TABLE rapatriement (
    age INT,
    ndos VARCHAR(255),
    nombf VARCHAR(255),
    dou DATE,
    dev INT,
    fcorr VARCHAR(255),
    nomdo VARCHAR(255),
    mdev NUMERIC,
    tdev NUMERIC,
    mcfa NUMERIC,
    motifd INT,
    cli INT,
    nomcli VARCHAR(255),
    gest VARCHAR(255),
    nomgest VARCHAR(255),
    etat VARCHAR(255)
);

-- Table transfert
CREATE TABLE transfert (
    age INT,
    ndos VARCHAR(255),
    nombf VARCHAR(255),
    dou DATE,
    dev INT,
    fcorr VARCHAR(255),
    nomdo VARCHAR(255),
    ncpdo VARCHAR(255),
    mdev NUMERIC,
    tdev NUMERIC,
    mcfa NUMERIC,
    cli INT,
    nomcli VARCHAR(255),
    gest VARCHAR(255),
    nomgest VARCHAR(255),
    etat VARCHAR(255)
);

-- Table flux_debiteur
CREATE TABLE flux_debiteur (
    Clients INT,
    Date DATE,
    Montant_Debiteur_XOF NUMERIC
);

-- Table flux_crediteur
CREATE TABLE flux_crediteur (
    Clients INT,
    Date DATE,
    Montant_Crediteur_XOF NUMERIC
);